using System;

namespace SistemaClientes.Models
{
    /// <summary>
    /// Representa um cliente no sistema.
    /// Contém todos os dados cadastrais de um cliente.
    /// </summary>
    public class Cliente
    {
        /// <summary>
        /// Identificador único do cliente (gerado automaticamente)
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nome completo do cliente
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Endereço de e-mail do cliente
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Número de telefone do cliente
        /// </summary>
        public string Telefone { get; set; }

        /// <summary>
        /// Data em que o cliente foi cadastrado no sistema
        /// </summary>
        public DateTime DataCadastro { get; set; }

        /// <summary>
        /// Construtor padrão — define a data de cadastro como agora
        /// </summary>
        public Cliente()
        {
            DataCadastro = DateTime.Now;
        }

        /// <summary>
        /// Retorna uma representação textual do cliente
        /// </summary>
        public override string ToString()
        {
            return string.Format("[{0}] {1} | {2} | {3} | Cadastro: {4:dd/MM/yyyy}",
                Id, Nome, Email, Telefone, DataCadastro);
        }
    }
}
