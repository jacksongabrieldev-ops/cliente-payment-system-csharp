# Sistema de Controle de Clientes e Pagamentos
### C# · .NET Framework 4.5.2 · Console Application

---

## Sumário

1. [Estrutura do Projeto](#estrutura-do-projeto)
2. [Arquitetura em Camadas](#arquitetura-em-camadas)
3. [Explicação de Cada Arquivo](#explicação-de-cada-arquivo)
4. [Como Compilar e Executar](#como-compilar-e-executar)
5. [Como Usar o Sistema](#como-usar-o-sistema)
6. [Banco de Dados (JSON)](#banco-de-dados-json)
7. [Conceitos OOP Aplicados](#conceitos-oop-aplicados)

---

## Estrutura do Projeto

```
SistemaClientes/
│
├── SistemaClientes.csproj      ← Arquivo de projeto MSBuild (.NET 4.5.2)
├── Program.cs                  ← Ponto de entrada, menu principal, DI manual
│
├── Models/
│   ├── Cliente.cs              ← Entidade Cliente (dados de um cliente)
│   └── Pagamento.cs            ← Entidade Pagamento + enum StatusPagamento
│
├── Data/
│   └── JsonDatabase.cs         ← Persistência em arquivo JSON (sem libs externas)
│
├── Services/
│   ├── ClienteService.cs       ← Regras de negócio de clientes
│   └── PagamentoService.cs     ← Regras de negócio de pagamentos
│
├── Controllers/
│   ├── ClienteController.cs    ← Entrada/saída do usuário para clientes
│   └── PagamentoController.cs  ← Entrada/saída do usuário para pagamentos
│
└── Utils/
    └── ConsoleHelper.cs        ← Utilitários de formatação do console
```

---

## Arquitetura em Camadas

```
  ┌─────────────┐
  │  Program.cs │  ← Ponto de entrada, monta as dependências e exibe o menu
  └──────┬──────┘
         │ usa
  ┌──────▼──────────────┐
  │    Controllers/     │  ← Recebe input do usuário, formata a saída
  │  ClienteController  │
  │ PagamentoController │
  └──────┬──────────────┘
         │ usa
  ┌──────▼──────────────┐
  │     Services/       │  ← Regras de negócio, validações
  │  ClienteService     │
  │  PagamentoService   │
  └──────┬──────────────┘
         │ usa
  ┌──────▼──────────────┐
  │      Data/          │  ← Lê e grava arquivos JSON
  │   JsonDatabase      │
  └─────────────────────┘
         │ persiste
  ┌──────▼──────────────┐
  │  clientes.json      │  ← Arquivos gerados automaticamente
  │  pagamentos.json    │
  └─────────────────────┘
```

**Por que separar em camadas?**
- Cada camada tem UMA responsabilidade clara
- Mudanças em uma camada não afetam as outras
- Facilita testes unitários (você pode testar o Service sem o Controller)
- Código mais fácil de entender e manter

---

## Explicação de Cada Arquivo

### `Models/Cliente.cs`
**O quê:** Classe que representa um cliente no mundo real.
**Contém:** `Id`, `Nome`, `Email`, `Telefone`, `DataCadastro`.
**Por quê:** Models são objetos "puros" que transportam dados. Não têm lógica de negócio nem acesso ao banco — apenas representam uma entidade.

---

### `Models/Pagamento.cs`
**O quê:** Classe que representa um pagamento, mais o enum `StatusPagamento`.
**Contém:** `Id`, `ClienteId`, `Cliente`, `Valor`, `DataPagamento`, `Status`.
**Destaque:** O campo `Cliente` é uma referência ao objeto cliente em memória — isso é chamado de **navegação de relacionamento**. O `ClienteId` é o que fica salvo no JSON.

---

### `Data/JsonDatabase.cs`
**O quê:** "Banco de dados" da aplicação baseado em arquivos JSON.
**Responsabilidade:** Ler e gravar dados em `clientes.json` e `pagamentos.json`.
**Decisão de projeto:** Implementamos o parser JSON manualmente (sem Newtonsoft.Json) para não precisar de NuGet, mantendo o projeto auto-suficiente e compatível com .NET 4.5.2 puro.

---

### `Services/ClienteService.cs`
**O quê:** Contém as regras de negócio para clientes.
**Exemplos de regras:** e-mail obrigatório e com `@`, nome não pode ser vazio, geração automática de ID sequencial.
**Por quê Service e não dentro do Controller?** O Controller pode mudar (hoje é console, amanhã pode ser WinForms ou Web API). As regras de negócio devem ser independentes da interface.

---

### `Services/PagamentoService.cs`
**O quê:** Regras de negócio para pagamentos.
**Destaque:** Método `ClientesComPendencias()` usa LINQ para cruzar pagamentos pendentes com clientes — exemplo de consulta expressiva em C#.

---

### `Controllers/ClienteController.cs`
**O quê:** Tudo que envolve interação com o usuário para clientes.
**Faz:** Lê dados do teclado, chama o Service, formata e imprime o resultado.
**NÃO faz:** Validações de negócio, acesso a arquivos — isso é papel do Service e do Data.

---

### `Controllers/PagamentoController.cs`
**O quê:** Interação com o usuário para pagamentos.
**Destaque:** Exibe pagamentos pendentes com cor vermelha e os pagamentos já realizados em verde, usando `Console.ForegroundColor`.

---

### `Utils/ConsoleHelper.cs`
**O quê:** Métodos estáticos para formatação visual do console.
**Por quê:** Evitar repetição de `Console.ForegroundColor = ConsoleColor.Red` em todo lugar. Qualquer mudança visual é feita em um só lugar.

---

### `Program.cs`
**O quê:** Ponto de entrada (`Main`), menu principal e composição das dependências.
**Destaque — Injeção de Dependência Manual:**
```csharp
var database            = new JsonDatabase();
var clienteService      = new ClienteService(database);
var pagamentoService    = new PagamentoService(database, clienteService);
var clienteController   = new ClienteController(clienteService);
var pagamentoController = new PagamentoController(pagamentoService, clienteService);
```
Cada classe recebe suas dependências pelo construtor — isso é o padrão **Dependency Injection** aplicado manualmente, sem container IoC.

---

## Como Compilar e Executar

### Opção 1 — Visual Studio (recomendado)
1. Abra o Visual Studio 2015 ou superior
2. `Arquivo → Abrir → Projeto/Solução`
3. Selecione `SistemaClientes.csproj`
4. Pressione `F5` para compilar e executar

### Opção 2 — MSBuild (linha de comando no Windows)
```bat
cd SistemaClientes
msbuild SistemaClientes.csproj /p:Configuration=Release
bin\Release\SistemaClientes.exe
```

### Opção 3 — Compilar com csc (C# Compiler)
```bat
csc /out:SistemaClientes.exe /target:exe ^
    Program.cs ^
    Models\Cliente.cs ^
    Models\Pagamento.cs ^
    Data\JsonDatabase.cs ^
    Services\ClienteService.cs ^
    Services\PagamentoService.cs ^
    Controllers\ClienteController.cs ^
    Controllers\PagamentoController.cs ^
    Utils\ConsoleHelper.cs
```

---

## Como Usar o Sistema

Ao iniciar, o menu principal aparece:

```
  ─────────────────────────────────────────────
   [1]  Cadastrar cliente
   [2]  Registrar pagamento
   [3]  Ver clientes
   [4]  Ver pagamentos
   [5]  Ver pagamentos pendentes
   [0]  Sair
  ─────────────────────────────────────────────
```

**Fluxo básico:**
1. Comece cadastrando pelo menos um cliente (opção 1)
2. Registre um pagamento para esse cliente (opção 2)
3. Visualize clientes (opção 3) e pagamentos (opção 4)
4. Veja o resumo de pendências (opção 5)

**Os arquivos `clientes.json` e `pagamentos.json` são criados automaticamente** na mesma pasta do executável na primeira vez que você cadastra dados.

---

## Banco de Dados (JSON)

### `clientes.json`
```json
[
  {
    "Id": 1,
    "Nome": "João Silva",
    "Email": "joao@email.com",
    "Telefone": "(11) 99999-0001",
    "DataCadastro": "2024-01-15T10:30:00"
  }
]
```

### `pagamentos.json`
```json
[
  {
    "Id": 1,
    "ClienteId": 1,
    "Valor": "350.00",
    "DataPagamento": "2024-01-20T00:00:00",
    "Status": 0
  }
]
```
> `Status 0 = Pendente`, `Status 1 = Pago`

---

## Conceitos OOP Aplicados

| Conceito | Onde é usado |
|---|---|
| **Encapsulamento** | Properties `{ get; set; }` em todas as models |
| **Herança** | `override ToString()` em `Cliente` e `Pagamento` |
| **Abstração** | Camadas escondem implementação umas das outras |
| **Enum** | `StatusPagamento` para valores fixos e legíveis |
| **Injeção de Dependência** | Dependências passadas pelo construtor |
| **Single Responsibility** | Cada classe tem apenas uma responsabilidade |
| **LINQ** | Consultas expressivas nos Services |
| **Tratamento de exceções** | `try/catch` com `ArgumentException` |
